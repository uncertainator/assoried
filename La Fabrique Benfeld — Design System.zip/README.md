# La Fabrique — Design System

> Identité visuelle et système de composants pour une association citoyenne en cours de création en Alsace.

---

## À propos de l'association

**La Fabrique** (nom de travail) est une **association citoyenne en cours de constitution** en Alsace. Sa mission s'articule autour de **quatre piliers** :

1. **Bien vivre** — améliorer le cadre de vie des habitants par des activités collectives, conviviales, ouvertes à tous.
2. **Écologie & sécurité** — sensibiliser, agir localement pour un quotidien plus sûr et plus respectueux de l'environnement.
3. **Fabrique à projets & innovation** — accompagner les habitants qui veulent monter un projet (associatif, professionnel, créatif).
4. **Activités économiques** — héberger une **conciergerie** et une **coopérative d'activités et d'emplois (CAE)** pour soutenir l'entrepreneuriat local.

**Public** : tout public — habitants, familles, seniors, jeunes, et **professionnels / commerçants / artisans locaux**.

**Implantation** : Alsace (Bas-Rhin) — territoire riche en patrimoine bâti (colombages, hôtels de ville Renaissance, halles).

> ⚠️ **Note importante** : Cette association n'existe pas encore officiellement. Le nom "La Fabrique" est une **proposition** issue de notre brief de design. Il est à valider et peut évoluer.

---

## Sources de design

Aucun matériel existant n'a été fourni (pas de logo, pas de site, pas de codebase). L'identité a été **créée from scratch** à partir du brief :
- Ton : patrimoine alsacien, chaleureux, accueillant, familial
- Direction visuelle : tons chauds (rouges, oranges, ocres)
- Langue : français
- Surfaces : site web public, espace adhérent, affiches/flyers, posts réseaux sociaux, newsletter, slides

**Inspiration culturelle** : architecture alsacienne (colombages, briques, tuiles), artisanat (poterie de Soufflenheim, terre cuite, bois patiné), papier des affiches anciennes, almanachs, paysages de la plaine du Ried.

---

## Index du système

```
.
├── README.md                   ← vous êtes ici
├── SKILL.md                    ← instructions pour agents (Claude Code, etc.)
├── colors_and_type.css         ← tokens CSS (couleurs, typo, espacement, ombres)
│
├── assets/                     ← logos, motifs, illustrations
│   ├── logo-primary.svg
│   ├── logo-mark.svg
│   ├── logo-horizontal.svg
│   ├── pattern-colombage.svg   ← motif décoratif inspiré des colombages
│   └── ...
│
├── preview/                    ← cartes pour l'onglet Design System
│   ├── colors-*.html
│   ├── type-*.html
│   ├── spacing-*.html
│   ├── components-*.html
│   └── brand-*.html
│
├── ui_kits/
│   ├── site_web/               ← UI kit du site public
│   ├── espace_adherent/        ← UI kit du portail adhérent
│   ├── print/                  ← affiches & flyers
│   ├── social/                 ← posts réseaux sociaux
│   └── newsletter/             ← templates email
│
└── slides/                     ← modèles AG / réunions
```

---

## CONTENT FUNDAMENTALS — La voix de La Fabrique

### Ton général

**Chaleureux, direct, citoyen.** On parle comme un voisin qui propose un coup de main, pas comme une administration. On évite le jargon associatif (« actions », « publics cibles », « politique d'inclusion ») au profit de mots simples (« on fait ensemble », « pour les gens d'ici », « entre nous »).

### Pronoms

- **« Nous »** quand l'association parle d'elle-même, mais avec retenue (pas de « nous » pompeux à chaque phrase).
- **« On »** est admis et même encouragé pour les formats conviviaux (réseaux sociaux, affiches d'événement). « On se retrouve samedi » est plus juste que « Nous vous invitons cordialement à nous rejoindre ».
- **« Vous »** pour s'adresser aux adhérents et au public — jamais « tu » (l'association touche tous les âges).
- Sauf cas explicite (ateliers ados / enfants), où le « tu » devient possible.

### Casse

- **Sentence case** partout. Pas de Title Case Anglais Sur Les Titres.
- Les mots en MAJUSCULES sont rares et **réservés aux eyebrows / labels** (« ÉVÉNEMENT », « ATELIER », « INSCRIPTION »).
- Pas de capitales artistiques en début de phrase autres que la première lettre.

### Vocabulaire de marque

| À privilégier             | À éviter                          |
|---------------------------|-----------------------------------|
| « habitants »             | « usagers », « bénéficiaires »    |
| « ensemble », « avec »    | « pour vous » (descendant)        |
| « se retrouver »          | « se rassembler »                 |
| « proposer »              | « organiser un dispositif »       |
| « la Fabrique »           | « la structure », « l'entité »    |
| « entre voisins »         | « au sein de la communauté »      |
| « bien vivre »            | « qualité de vie »                |
| « projet »                | « initiative » (sauf si précis)   |

### Émojis

**Usage parcimonieux.** Acceptables sur les réseaux sociaux et la newsletter — jamais dans les titres du site, ni sur les affiches print, ni dans l'espace adhérent. Préférer un seul émoji par publication, et choisir des émojis sobres et concrets : 🌱 🍞 🔧 🪵 🧰 🌾 🏡 ☕ 🤝. Éviter les émojis trop expressifs (🎉🚀✨🔥) qui sonnent corporate.

### Vibe — exemples concrets

✅ **À l'oreille juste** :
> « Cet automne, on lance une fabrique à idées. Vous avez un projet, une envie, un savoir-faire à partager ? On en discute, samedi 18 octobre, autour d'un café. »

> « Trois habitants se sont retrouvés autour d'un compost partagé. Six mois plus tard, c'est un jardin de quartier. La Fabrique, c'est ça. »

> « Inscriptions ouvertes — atelier vélo, jeudi 19h, place de la Mairie. »

❌ **Trop institutionnel** :
> « La Fabrique a le plaisir de vous convier à la session inaugurale de son dispositif d'incubation citoyenne, qui se tiendra le samedi 18 octobre dans nos locaux associatifs. »

❌ **Trop corporate / startup** :
> « Boostez votre projet ! 🚀 Rejoignez l'écosystème innovant de La Fabrique pour transformer vos idées en réalité ✨ »

### Microcopy

- Boutons : verbes à l'impératif, courts. **« Participer »**, **« S'inscrire »**, **« Découvrir »**, **« Nous écrire »**, **« Lire la suite »**. Pas de « Cliquez ici ».
- Champs vides : phrases concrètes. « Votre prénom », « votre.email@exemple.fr », « Dites-nous quelques mots… »
- Confirmations : chaleureuses. « C'est noté, on se retrouve samedi ! » plutôt que « Votre inscription a été enregistrée avec succès. »
- Erreurs : humaines, jamais accusatrices. « On n'a pas reconnu cet email — vous voulez réessayer ? »

---

## VISUAL FOUNDATIONS

### Couleurs

Palette **chaude, terreuse, alsacienne**. Cinq familles, 5–10 valeurs chacune. Tokens dans `colors_and_type.css`.

| Famille    | Rôle                          | Inspiration                          |
|------------|-------------------------------|--------------------------------------|
| **Brique** (rouge-orangé) | Couleur primaire de marque     | Colombages, terre cuite, briques     |
| **Ocre** (jaune doré)     | Accent chaleureux              | Blé mûr, paille, soleil sur vignes   |
| **Mousse** (vert profond) | Pilier écologie / nature       | Forêts du Ried, mousse sur pierre    |
| **Crème** (off-white)     | Fonds — jamais de blanc pur    | Papier ancien, plâtre chaulé         |
| **Encre** (brun-noir)     | Texte                          | Encre sépia, bois patiné             |

**Règles d'usage** :
- Brique = couleur dominante (boutons primaires, accents, logo).
- Ocre = couleur d'accent vive (badges, highlights, illustrations).
- Mousse = quand on parle d'écologie / nature / extérieur.
- Le crème est **toujours** le fond. Jamais `#ffffff` pur sauf cas exceptionnel (cartes en élévation supérieure).
- Le texte est **toujours** en encre, jamais en gris pur.
- Pas de gradient bleu-violet AI-slop. Si gradient, alors entre brique et ocre seulement.

### Typographie

- **Display** : `Newsreader` — serif moderne avec contraste doux et un côté littéraire chaleureux. Pour H1, H2, H3, citations, leads.
- **Sans** : `Public Sans` — UI, corps de texte, boutons. Géométrique mais humaniste, lisible à toutes les tailles.
- **Script** : `Caveat` — usage occasionnel pour signatures, annotations, eyebrows manuscrits sur affiches/social. Jamais en bloc de texte.
- **Mono** : `JetBrains Mono` — codes, données, dates, horaires sur affiches techniques.

**Règles** :
- Le serif (`Newsreader`) porte le caractère de la marque. Toujours en **italique 600** pour les emphases lyriques. En romain 600 pour les titres standards.
- **`text-wrap: balance`** sur tous les titres. **`text-wrap: pretty`** sur les corps de texte.
- Tracking légèrement négatif (`-0.02em`) sur les gros titres serif, neutre sur le sans.
- Les eyebrows (kicker au-dessus d'un titre) sont **MAJUSCULES, sans-serif, 12px, lettres espacées (0.12em), couleur brique**.

### Espacement

Échelle 4px : `4, 8, 12, 16, 24, 32, 48, 64, 96, 128`. Préférer flex/grid + `gap` à des marges ad hoc.

### Fonds & textures

- Fond principal **toujours** en `--creme-50` (`#fdfaf3`). Le crème porte la marque autant que la brique.
- **Pas de gradients radiaux** ni de gradients arc-en-ciel. Si gradient, c'est un dégradé linéaire chaud (brique → ocre, ou ocre → crème).
- **Texture papier** subtile autorisée sur grandes surfaces (slides, affiches) — jamais agressive, opacité < 8%.
- **Motif colombage** : géométrie minimale (lignes croisées sobres), à utiliser comme **élément graphique de marque** discret (en-tête de section, footer, en filigrane sur affiches). Jamais une frise omniprésente — c'est un sceau, pas un papier peint.
- **Pas d'illustrations 3D** style memphis/blob. Si illustrations, **lignes sobres et tachés solides** dans la palette, jamais détaillées comme une icône d'application.

### Animation

- **Calme, jamais rebondissant.** Pas de spring AI-slop.
- Easings standards : `cubic-bezier(0.22, 1, 0.36, 1)` (ease-out) et `cubic-bezier(0.65, 0, 0.35, 1)` (ease-in-out).
- Durées : `120ms` (réactions immédiates), `220ms` (transitions standard), `420ms` (entrées d'éléments).
- Préférer **fades + slides courts (8–12px)** aux scales/rotations/explosions.
- Hover : transition de couleur uniquement, jamais de scale.

### États interactifs

- **Hover** sur boutons primaires : passage à la teinte 600 (un cran plus foncé). Pas de scale, pas d'ombre amplifiée.
- **Hover** sur liens / textes : changement de couleur vers brique-700 + soulignement apparu si absent.
- **Active / press** : passage à la teinte 700 + très léger `transform: translateY(1px)`.
- **Focus** : halo chaleureux (`--glow-brique` ou `--glow-ocre`) — jamais le ring bleu navigateur par défaut.
- **Disabled** : opacité 0.4, cursor not-allowed, pas de hover.

### Bordures, cartes & élévation

- **Coins** : généreux mais pas mous. Cartes principales = `--radius-lg` (14px). Boutons = `--radius-md` (8px) ou `--radius-pill` (selon le ton). Champs de formulaire = `--radius-md`.
- **Bordures** : 1px solide, couleur `--border-default` ou `--border-subtle`. Préférer une bordure visible plutôt qu'une ombre seule — la marque a un côté "trait dessiné", honnête.
- **Cartes** : fond `--bg-surface` (crème-100) + bordure subtle + ombre `--shadow-sm`. Sur fond crème, la carte se distingue par un crème un cran plus saturé. Sur fond brique foncé (hero, section sombre), la carte est en crème ou blanc avec ombre `--shadow-md`.
- **Cartes spéciales (events, témoignages)** : peuvent avoir un **filet supérieur de couleur** (3px, en brique ou ocre) en haut, façon ticket/affiche d'antan. **Pas** de barre verticale gauche colorée (AI-slop).

### Ombres

- Toutes teintées en brun-rouge (`rgba(74, 28, 16, …)`). **Jamais d'ombres grises** — elles cassent la cohérence chaleureuse.
- 5 niveaux : xs, sm, md, lg, xl. La majorité des cartes s'en tiennent à `sm` et `md`.
- Un `shadow-inset` pour les inputs et les puits.

### Transparence & flou

- **Usage minimal.** L'identité est franche, mate, opaque. Le flou (backdrop-blur) ne s'utilise que sur des nav/header sticky qui survolent du contenu.
- Une transparence de 8% sur la texture papier des grands fonds est acceptable.

### Layout

- **Grille fluide à 12 colonnes** sur web, marge de 24px en mobile, 64–96px en desktop.
- **Marge max-width** sur les blocs de prose : 65ch.
- Le **logo est toujours en haut à gauche** sur desktop, centré au-dessus en mobile.
- Le footer est sobre, sur fond `--encre-600` ou `--brique-800`.

### Photographie

Photos chaleureuses, lumière dorée de fin d'après-midi. **Pas de stock photo lisse**. Privilégier des photos authentiques d'habitants, d'ateliers, de mains au travail, de marchés, de paysages alsaciens. Si stock photo nécessaire, choisir des images au **grain visible**, **dominante chaude**, **scènes intimistes** plutôt que glossy. Convertir si besoin avec un léger filtre chaud (légère désaturation des bleus).

---

## ICONOGRAPHY

L'iconographie est **fonctionnelle et sobre**, jamais décorative pour rien.

### Set principal

**Lucide** ([lucide.dev](https://lucide.dev)) — chargé via CDN. Stroke 1.75–2px, coins arrondis, style "main levée" subtile. Cohérent avec le côté artisanal sans être folklorique.

```html
<!-- Usage typique -->
<i data-lucide="calendar" stroke-width="1.75"></i>
<script src="https://unpkg.com/lucide@latest"></script>
<script>lucide.createIcons();</script>
```

**Taille par défaut** : 20px dans le corps, 24px dans la nav, 16px inline avec du texte.

**Couleur** : héritée du `currentColor`. Sur les boutons primaires, blanc cassé. Dans le corps, `--fg-secondary`.

### Iconographie de marque

Quelques pictogrammes maison vivent dans `assets/` — minimalistes, en SVG, pour les piliers de l'association :

- `pilier-bien-vivre.svg` — une maison stylisée
- `pilier-ecologie.svg` — une feuille
- `pilier-fabrique.svg` — un marteau ou un outil
- `pilier-cooperative.svg` — deux mains qui se serrent

Ces pictos peuvent être colorisés (brique, ocre, mousse) selon le contexte. Ils sont **toujours plus gros** que les icônes Lucide standards (32–64px) — ce sont des sceaux, pas des icônes UI.

### Émojis comme icônes

**Jamais en remplacement d'icône UI.** Acceptables uniquement dans le contenu (réseaux sociaux, newsletter ponctuellement). Voir section CONTENT FUNDAMENTALS.

### Caractères Unicode

`→ ← ↗ ↘ • · — –` autorisés et même encouragés (typographie soignée, plutôt que `->` ou `*`). `« »` toujours pour les guillemets français, avec espaces insécables.

---

## Surfaces couvertes (UI kits)

| Surface             | Dossier                          | Description                                   |
|---------------------|----------------------------------|-----------------------------------------------|
| Site web public     | `ui_kits/site_web/`              | Accueil, activités, événements, contact       |
| Espace adhérent     | `ui_kits/espace_adherent/`       | Connexion, dashboard, profil, inscriptions    |
| Print               | `ui_kits/print/`                 | Affiche A3, flyer A5                          |
| Réseaux sociaux     | `ui_kits/social/`                | Posts Instagram / Facebook (1080×1080, 1080×1350) |
| Newsletter          | `ui_kits/newsletter/`            | Email HTML 600px                              |
| Slides              | `slides/`                        | Modèles AG / réunions (1280×720)              |

---

## Caveats / à valider

- **Le nom "La Fabrique"** est une proposition — à valider avec les fondateurs.
- **Les fonts** sont Google Fonts (Newsreader, Public Sans, Caveat, JetBrains Mono). Si vous voulez des fonts spécifiques (achetées, libres mais non Google), me le dire.
- **Les couleurs** sont une interprétation du brief "tons chauds + patrimoine alsacien" — peuvent être ajustées.
- **Les photos** dans les UI kits sont des placeholders ; à remplacer par de vraies photos d'habitants, d'événements, du territoire.
- **Le logo** est un dessin maison initial — à itérer avec un designer graphique pour la version finale.
