# UI Kit — Newsletter (email HTML)

Email mensuel, format 600px. Compatible boîtes mail standards (table-based).
