# UI Kit — Réseaux sociaux

Posts Instagram / Facebook : carré (1080×1080), portrait (1080×1350), story (1080×1920). Échelle réduite pour preview.
