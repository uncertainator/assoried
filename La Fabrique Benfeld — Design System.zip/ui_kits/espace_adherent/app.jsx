/* @jsx React.createElement */
const { useState } = React;

function LoginScreen({ onSubmit }) {
  return (
    <div className="ea-login-page">
      <div className="ea-login-side">
        <div className="ea-side-logo">La Fabrique</div>
        <div>
          <div className="ea-side-quote">« On se retrouve, on fait ensemble. C'est tout. »</div>
          <div className="ea-side-author">
            <span className="ea-side-name">— Jean-Paul</span>
            <span className="ea-side-role">président de la Fabrique</span>
          </div>
        </div>
        <div style={{ fontSize: 12, color: 'var(--brique-200)' }}>Alsace · Bas-Rhin</div>
      </div>
      <div className="ea-login-form">
        <div className="ea-login-form-inner">
          <div className="ea-login-eyebrow">Espace adhérent</div>
          <h1 className="ea-login-title">Bonjour 👋</h1>
          <p className="ea-login-sub">Content de vous revoir. Connectez-vous pour voir vos inscriptions et nouvelles activités.</p>
          <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }}>
            <div className="ea-field">
              <label>Email</label>
              <input type="email" defaultValue="anne@bahl.fr" />
            </div>
            <div className="ea-field">
              <label>Mot de passe</label>
              <input type="password" defaultValue="••••••••" />
            </div>
            <div className="ea-row">
              <label><input type="checkbox" defaultChecked style={{ accentColor: 'var(--brique-500)' }} /> Se souvenir de moi</label>
              <a href="#">Mot de passe oublié ?</a>
            </div>
            <button type="submit" className="ea-btn-primary">Se connecter →</button>
          </form>
          <div className="ea-divider"><span>ou</span></div>
          <div className="ea-signup-link">Pas encore adhérent ? <a href="#">Rejoindre la Fabrique</a></div>
        </div>
      </div>
    </div>
  );
}

const NavIcon = ({ d }) => (
  <svg className="ea-nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    {d}
  </svg>
);

function Sidebar() {
  const items = [
    { id: 'home', label: 'Accueil', active: true, d: <><path d="M3 12l9-9 9 9"/><path d="M5 10v10h14V10"/></> },
    { id: 'events', label: 'Mes inscriptions', d: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 9h18M8 3v4M16 3v4"/></> },
    { id: 'agenda', label: 'Agenda', d: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></> },
    { id: 'projects', label: 'Mes projets', d: <><path d="M4 7l8-4 8 4-8 4-8-4z"/><path d="M4 12l8 4 8-4M4 17l8 4 8-4"/></> },
  ];
  const items2 = [
    { id: 'profile', label: 'Mon profil', d: <><circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 5-7 8-7s7 2 8 7"/></> },
    { id: 'cot', label: 'Cotisation', d: <><rect x="3" y="6" width="18" height="13" rx="2"/><path d="M3 10h18"/></> },
    { id: 'settings', label: 'Paramètres', d: <><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.1l2-1.5-2-3.5-2.4 1a7 7 0 0 0-1.9-1.1L14 3h-4l-.6 2.8a7 7 0 0 0-1.9 1.1l-2.4-1-2 3.5 2 1.5a7 7 0 0 0 0 2.2l-2 1.5 2 3.5 2.4-1a7 7 0 0 0 1.9 1.1L10 21h4l.6-2.8a7 7 0 0 0 1.9-1.1l2.4 1 2-3.5-2-1.5c.07-.4.1-.74.1-1.1z"/></> },
  ];
  return (
    <aside className="ea-side">
      <div className="ea-side-brand">
        <img src="../../assets/logo-mark.svg" width="28" height="28" alt="" />
        <span className="ea-side-brand-text">La Fabrique</span>
      </div>
      <div className="ea-nav-section">Espace</div>
      {items.map(i => <a key={i.id} className={`ea-nav-item ${i.active ? 'active' : ''}`}><NavIcon d={i.d} />{i.label}</a>)}
      <div className="ea-nav-section">Compte</div>
      {items2.map(i => <a key={i.id} className="ea-nav-item"><NavIcon d={i.d} />{i.label}</a>)}
      <div className="ea-side-foot">
        <div className="ea-avatar">AB</div>
        <div>
          <div className="ea-side-name-2">Anne Bahl</div>
          <div className="ea-side-role-2">Adhérente · 2024</div>
        </div>
      </div>
    </aside>
  );
}

function Dashboard() {
  return (
    <div className="ea-app">
      <Sidebar />
      <main className="ea-main">
        <div className="ea-topbar">
          <div>
            <h1 className="ea-greeting">Bonjour <em>Anne</em>,</h1>
            <div className="ea-greeting-sub">Trois activités vous attendent ce mois-ci.</div>
          </div>
          <div className="ea-topbar-actions">
            <button className="ea-btn-primary" style={{ width: 'auto', padding: '10px 18px', fontSize: 14 }}>Proposer un projet</button>
          </div>
        </div>

        <div className="ea-stats">
          <div className="ea-stat">
            <div className="ea-stat-label">Mes inscriptions</div>
            <div className="ea-stat-val">3<em>/12 places</em></div>
            <div className="ea-stat-trend">+1 ce mois</div>
          </div>
          <div className="ea-stat">
            <div className="ea-stat-label">Cotisation</div>
            <div className="ea-stat-val">2025</div>
            <div className="ea-stat-trend">À jour · 10 €</div>
          </div>
          <div className="ea-stat">
            <div className="ea-stat-label">Bénévolat</div>
            <div className="ea-stat-val">14<em> heures</em></div>
            <div className="ea-stat-trend" style={{ color: 'var(--ocre-600)' }}>Merci !</div>
          </div>
          <div className="ea-stat">
            <div className="ea-stat-label">Projets en cours</div>
            <div className="ea-stat-val">2</div>
            <div className="ea-stat-trend" style={{ color: 'var(--fg-tertiary)' }}>Compost · Café idées</div>
          </div>
        </div>

        <div className="ea-cols">
          <div className="ea-panel">
            <div className="ea-panel-head">
              <h2 className="ea-panel-title">Mes prochaines activités</h2>
              <a href="#" className="ea-panel-link">Tout voir →</a>
            </div>
            {[
              { day: '16', month: 'OCT', name: 'Réparer son vélo, entre voisins', meta: 'JEU 19:00 · Place de la Mairie', status: 'confirmed' },
              { day: '18', month: 'OCT', name: 'Café des idées', meta: 'SAM 09:30 · Salle des fêtes', status: 'confirmed' },
              { day: '26', month: 'OCT', name: 'Compost partagé, mode d\'emploi', meta: 'DIM 11:00 · Jardin du presbytère', status: 'pending' },
            ].map((e, i) => (
              <div key={i} className="ea-event-row">
                <div className="ea-event-date">
                  <div className="ea-event-day">{e.day}</div>
                  <div className="ea-event-month">{e.month}</div>
                </div>
                <div className="ea-event-info">
                  <div className="ea-event-name">{e.name}</div>
                  <div className="ea-event-meta-2">{e.meta}</div>
                </div>
                <div className={`ea-event-status ${e.status}`}>
                  {e.status === 'confirmed' ? '✓ Inscrit' : '○ En attente'}
                </div>
              </div>
            ))}
          </div>

          <div>
            <div className="ea-panel" style={{ marginBottom: 16 }}>
              <div className="ea-panel-head">
                <h2 className="ea-panel-title">À découvrir</h2>
              </div>
              <div className="ea-quick-card">
                <div className="ea-quick-eyebrow">Nouveau</div>
                <h3 className="ea-quick-title">Atelier couture, novembre</h3>
                <p className="ea-quick-desc">5 séances pour apprendre à raccommoder, transformer.</p>
                <a href="#" className="ea-quick-action">Je m'inscris →</a>
              </div>
              <div className="ea-quick-card" style={{ marginBottom: 0, background: 'var(--mousse-100)', borderColor: 'var(--mousse-200)' }}>
                <div className="ea-quick-eyebrow" style={{ color: 'var(--mousse-600)' }}>Écologie</div>
                <h3 className="ea-quick-title">Vente de plants, printemps</h3>
                <p className="ea-quick-desc">Réservez vos semis dès maintenant.</p>
                <a href="#" className="ea-quick-action" style={{ color: 'var(--mousse-600)' }}>Réserver →</a>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function App() {
  const [logged, setLogged] = useState(false);
  return logged ? <Dashboard /> : <LoginScreen onSubmit={() => setLogged(true)} />;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
