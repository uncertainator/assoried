/* @jsx React.createElement */
const { useState } = React;

function Header({ active = 'accueil' }) {
  const links = [
    ['accueil', 'Accueil'],
    ['activites', 'Activités'],
    ['projets', 'Fabrique à projets'],
    ['adherer', 'Adhérer'],
    ['contact', 'Contact'],
  ];
  return (
    <header className="fb-header">
      <a href="#" className="fb-logo">
        <img src="../../assets/logo-mark.svg" alt="" width="40" height="40" />
        <span className="fb-logo-text">La Fabrique</span>
      </a>
      <nav className="fb-links">
        {links.map(([id, label]) => (
          <a key={id} href="#" className={active === id ? 'active' : ''}>{label}</a>
        ))}
      </nav>
      <button className="fb-btn fb-btn-primary fb-btn-sm">Espace adhérent →</button>
    </header>
  );
}

function Hero() {
  return (
    <section className="fb-hero">
      <div className="fb-hero-pattern" aria-hidden="true" />
      <div className="fb-hero-content">
        <div className="fb-eyebrow">Association citoyenne · Alsace</div>
        <h1 className="fb-h1">
          Une fabrique <em className="fb-italic-accent">à idées,</em><br />
          entre voisins.
        </h1>
        <p className="fb-lead" style={{ maxWidth: '52ch' }}>
          On améliore le cadre de vie ensemble — par des activités, des projets, et l'envie de bien vivre dans notre ville.
        </p>
        <div style={{ display: 'flex', gap: 12, marginTop: 28 }}>
          <button className="fb-btn fb-btn-primary fb-btn-lg">Découvrir nos activités</button>
          <button className="fb-btn fb-btn-outline fb-btn-lg">Devenir adhérent</button>
        </div>
        <div className="fb-hero-meta">
          <span><strong>4</strong> piliers</span>
          <span className="fb-meta-dot">·</span>
          <span><strong>32</strong> activités</span>
          <span className="fb-meta-dot">·</span>
          <span><strong>120+</strong> habitants engagés</span>
        </div>
      </div>
      <div className="fb-hero-side">
        <div className="fb-hero-card">
          <div className="fb-eyebrow">Prochain rendez-vous</div>
          <h3 className="fb-card-title">Café des idées</h3>
          <p className="fb-card-body">Vous avez une envie, un projet ? On en discute autour d'un café.</p>
          <div className="fb-card-meta">SAM 18 OCT · 09:30 · Salle des fêtes</div>
          <button className="fb-btn fb-btn-primary fb-btn-block" style={{whiteSpace: 'nowrap'}}>Je viens →</button>
        </div>
      </div>
    </section>
  );
}

function PiliersSection() {
  const piliers = [
    { id: 'bv', name: 'Bien vivre', desc: "Animations, ateliers et moments partagés pour mieux se connaître entre voisins.", color: 'var(--brique-500)', icon: 'bien-vivre' },
    { id: 'ec', name: 'Écologie & sécurité', desc: "Compost partagé, jardin de quartier, vigilance — agir au quotidien.", color: 'var(--mousse-500)', icon: 'ecologie' },
    { id: 'fa', name: 'Fabrique à projets', desc: "Vous avez une idée ? On vous aide à la mettre en route.", color: 'var(--ocre-500)', icon: 'fabrique' },
    { id: 'co', name: 'Coopérative', desc: "Conciergerie et CAE pour soutenir l'entrepreneuriat local.", color: 'var(--brique-700)', icon: 'cooperative' },
  ];
  return (
    <section className="fb-section">
      <div className="fb-section-head">
        <div className="fb-eyebrow">Ce qu'on fait</div>
        <h2 className="fb-h2">Quatre piliers, un même fil rouge</h2>
      </div>
      <div className="fb-piliers-grid">
        {piliers.map(p => (
          <article key={p.id} className="fb-pilier">
            <div className="fb-pilier-icon" style={{ color: p.color }}>
              <img src={`../../assets/pilier-${p.icon}.svg`} alt="" width="48" height="48" style={{ filter: 'none' }} />
            </div>
            <h3 className="fb-pilier-name">{p.name}</h3>
            <p className="fb-pilier-desc">{p.desc}</p>
            <a href="#" className="fb-pilier-link">En savoir plus →</a>
          </article>
        ))}
      </div>
    </section>
  );
}

function EventCard({ tag, tagColor, title, body, date, time, place, places, accent }) {
  return (
    <article className="fb-event-card" style={{ borderTopColor: accent || 'var(--ocre-400)' }}>
      <div className="fb-event-tag" style={{ color: tagColor || 'var(--brique-600)' }}>{tag}</div>
      <h3 className="fb-event-title">{title}</h3>
      <p className="fb-event-body">{body}</p>
      <div className="fb-event-meta">
        <span className="fb-mono">{date} · {time}</span>
        <span className="fb-event-place">{place}</span>
      </div>
      <div className="fb-event-foot">
        <span className="fb-badge fb-badge-mousse">{places} places</span>
        <button className="fb-btn fb-btn-ghost fb-btn-sm">Je m'inscris →</button>
      </div>
    </article>
  );
}

function EventsSection() {
  return (
    <section className="fb-section fb-section-creme">
      <div className="fb-section-head">
        <div className="fb-eyebrow">Agenda</div>
        <h2 className="fb-h2">À venir, près de chez vous</h2>
        <a href="#" className="fb-section-link">Voir tout l'agenda →</a>
      </div>
      <div className="fb-events-grid">
        <EventCard
          tag="ATELIER · JEUDI"
          tagColor="var(--brique-600)"
          accent="var(--brique-500)"
          title="Réparer son vélo, entre voisins"
          body="On apporte sa monture, on partage les outils. Pas besoin d'être bricoleur."
          date="JEU 16.10"
          time="19:00"
          place="Place de la Mairie"
          places="6/12"
        />
        <EventCard
          tag="FABRIQUE · SAMEDI"
          tagColor="var(--ocre-600)"
          accent="var(--ocre-400)"
          title="Café des idées"
          body="Vous avez un projet, une envie ? On en discute autour d'un café."
          date="SAM 18.10"
          time="09:30"
          place="Salle des fêtes"
          places="12/30"
        />
        <EventCard
          tag="ÉCOLOGIE · DIMANCHE"
          tagColor="var(--mousse-500)"
          accent="var(--mousse-500)"
          title="Compost partagé, mode d'emploi"
          body="Visite du nouveau composteur de quartier. Comment l'utiliser, qu'y mettre."
          date="DIM 26.10"
          time="11:00"
          place="Jardin du presbytère"
          places="8/20"
        />
      </div>
    </section>
  );
}

function Testimonial() {
  return (
    <section className="fb-section fb-section-brique">
      <div className="fb-testimonial">
        <div className="fb-quote-mark">«</div>
        <blockquote className="fb-quote-text">
          On a commencé à trois autour d'un compost. Six mois plus tard, c'est un jardin de quartier qui nourrit huit familles. La Fabrique, c'est ça : on commence petit, on fait ensemble.
        </blockquote>
        <div className="fb-quote-author">
          <span className="fb-quote-name">Anne Bahl</span>
          <span className="fb-quote-role">— habitante, rue du Grand Rempart</span>
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="fb-section">
      <div className="fb-cta">
        <div>
          <div className="fb-eyebrow">Adhérer</div>
          <h2 className="fb-h2">Rejoignez la Fabrique</h2>
          <p className="fb-lead">10 € par an, par famille. Pour soutenir, et pour participer aux décisions.</p>
        </div>
        <div className="fb-cta-actions">
          <button className="fb-btn fb-btn-primary fb-btn-lg">Devenir adhérent →</button>
          <a href="#" className="fb-link-quiet">ou nous écrire d'abord</a>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="fb-footer">
      <div className="fb-footer-pattern" aria-hidden="true" />
      <div className="fb-footer-inner">
        <div>
          <div className="fb-footer-logo">La Fabrique</div>
          <p className="fb-footer-baseline">Association citoyenne · Alsace</p>
        </div>
        <div className="fb-footer-cols">
          <div>
            <div className="fb-footer-head">L'association</div>
            <a href="#">Qui sommes-nous</a>
            <a href="#">Statuts</a>
            <a href="#">Adhérer</a>
          </div>
          <div>
            <div className="fb-footer-head">Activités</div>
            <a href="#">Agenda</a>
            <a href="#">Ateliers</a>
            <a href="#">Projets</a>
          </div>
          <div>
            <div className="fb-footer-head">Nous joindre</div>
            <a href="#">Alsace</a>
            <a href="#">Bas-Rhin</a>
            <a href="#">bonjour@lafabrique.fr</a>
          </div>
        </div>
      </div>
      <div className="fb-footer-bottom">
        <span>© 2025 La Fabrique</span>
        <span className="fb-script">— faits ensemble.</span>
      </div>
    </footer>
  );
}

window.FB = { Header, Hero, PiliersSection, EventCard, EventsSection, Testimonial, CTA, Footer };
