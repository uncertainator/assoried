# UI Kit — Site web public

Site web vitrine pour La Fabrique. Pages : accueil, activités, événement, adhérer, contact.

## Composants
- `Header.jsx` — nav principale
- `Hero.jsx` — bandeau d'accueil avec motif colombage en filigrane
- `PiliersSection.jsx` — les 4 piliers
- `EventCard.jsx` / `EventList.jsx` — événements à venir
- `Testimonial.jsx` — citation d'habitant
- `CTA.jsx` — appel à devenir adhérent
- `Footer.jsx`

## Page principale
`index.html` — homepage interactive.
