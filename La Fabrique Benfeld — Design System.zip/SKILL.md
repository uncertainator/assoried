---
name: la-fabrique-design
description: Use this skill to generate well-branded interfaces and assets for La Fabrique, an Alsatian citizen association, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files (`colors_and_type.css`, `assets/`, `ui_kits/`, `slides/`).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. The brand uses warm Alsatian tones — brique (#c85226), ocre (#e3a528), mousse (#4a6e30), crème (#fdfaf3), encre (#1d1a10) — with Newsreader (display) + Public Sans (UI) + Caveat (script) typography. The visual signature is the colombage (half-timbering) pattern used as a subtle watermark.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand. Tone of voice is warm, direct, neighborly French — never corporate, never administrative. Use "on" and "ensemble" liberally; avoid emoji on print/UI surfaces; use them sparingly on social/newsletter only.

If the user invokes this skill without any other guidance, ask them what they want to build or design (event poster ? Instagram post ? new landing page section ?), ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
